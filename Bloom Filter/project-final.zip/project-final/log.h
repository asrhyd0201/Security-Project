
void timestamp(char *a);
void logCreate(BLOOM *bitArray);
