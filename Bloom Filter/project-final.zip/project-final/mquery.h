#include"bloom.h"
int findPayload(char *payload);
int findMail(char *mailid);
void bloomRetrieve(BLOOM *bloom,char *fileName);
